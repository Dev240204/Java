interface Dress {
  void wear();
}

class BasicDress implements Dress {
  public void wear() {
      System.out.println("Wearing basic dress.");
  }
}

abstract class DressDecorator implements Dress {
  protected Dress dress;

  public DressDecorator(Dress dress) {
      this.dress = dress;
  }

  public void wear() {
      dress.wear();
  }
}

class DressWithPattern extends DressDecorator {
  public DressWithPattern(Dress dress) {
      super(dress);
  }

  public void wear() {
      super.wear();
      System.out.println("Adding pattern to dress.");
  }
}

public class decoratordesign {
  public static void main(String[] args) {
      Dress dress = new BasicDress();

      dress = new DressWithPattern(dress);

      dress.wear();
  }
}
