package adapter2;
public interface Pen 
{
	void write(String str);

}