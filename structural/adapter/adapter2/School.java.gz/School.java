class AssignmentWork 
{
	private Pen p;
	
	public Pen getP() {
		return p;
	}
	public void setP(Pen p) {
	}
	public void writeAssignment(String str)
	{
		p.write(str);
	}

}

interface Pen 
{
	void write(String str);

}

class PenAdapter implements Pen
{
    PilotPen pp=new PilotPen();
    
	@Override
	public void write(String str) 
	{
		pp.mark(str);
		
	}

}

class PilotPen 
{
	public void mark(String str)
	{
		System.out.println(str);
	}

}

public class School {

	public static void main(String[] args) 
	{
		AssignmentWork as= new AssignmentWork();

		Pen pa=new PenAdapter();
		as.setP(pa);
		as.writeAssignment("I am bit tired to write assignment");
		

	}

}