package adapter2;
public class PilotPen 
{
	public void mark(String str)
	{
		System.out.println(str);
	}

}