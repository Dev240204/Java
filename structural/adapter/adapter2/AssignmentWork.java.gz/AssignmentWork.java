package adapter2;
public class AssignmentWork 
{
	private Pen p;
	
	public Pen getP() {
		return p;
	}
	public void setP(Pen p) {
	}
	public void writeAssignment(String str)
	{
		p.write(str);
	}

}