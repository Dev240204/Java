class Engine {
    public void start() {
        System.out.println("Engine started");
    }
    public void stop() {
        System.out.println("Engine stopped");
    }
}

class Transmission {
    public void shiftUp() {
        System.out.println("Shifted up");
    }
    public void shiftDown() {
        System.out.println("Shifted down");
    }
}

class Ignition {
    public void turnOn() {
        System.out.println("Ignition turned on");
    }
    public void turnOff() {
        System.out.println("Ignition turned off");
    }
}

class CarFacade {
    private Engine engine;
    private Transmission transmission;
    private Ignition ignition;

    public CarFacade() {
        engine = new Engine();
        transmission = new Transmission();
        ignition = new Ignition();
    }

    public void startCar() {
        ignition.turnOn();
        engine.start();
        transmission.shiftUp();
    }

    public void stopCar() {
        transmission.shiftDown();
        engine.stop();
        ignition.turnOff();
    }
}

public class Automobile {
    public static void main(String[] args) {
        CarFacade car = new CarFacade();

        car.startCar();
        System.out.println("-----------------------");
        car.stopCar();
    }
}
