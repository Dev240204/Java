import java.util.HashMap;
import java.util.Map;

class CarFactory {
    private static final Map<String, Car> carMap = new HashMap<>();

    public static Car getCar(String brand, String model, int year) {
        String key = brand + model + year;
        Car car = carMap.get(key);

        if (car == null) {
            car = new Car(brand, model, year);
            carMap.put(key, car);
        }

        return car;
    }
}

class Car {
    private String brand;
    private String model;
    private int year;

    public Car(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
    }

    public void start() {
        System.out.println("Starting " + brand + " " + model + " " + year);
    }
}

public class flyweight2 {
    public static void main(String[] args) {
        Car car1 = CarFactory.getCar("Toyota", "Camry", 2020);
        Car car2 = CarFactory.getCar("Toyota", "Camry", 2020);
        Car car3 = CarFactory.getCar("Honda", "Accord", 2021);

        car1.start();
        car2.start();
        car3.start();
    }
}
