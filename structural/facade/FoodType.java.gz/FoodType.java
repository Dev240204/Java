package structural.facade;

public enum FoodType {
        Pasta,
        Pizza
}
