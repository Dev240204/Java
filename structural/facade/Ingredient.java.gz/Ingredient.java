package structural.facade;

public class Ingredient {

    public String getPastaItems(){
        return "Tomato, Cheese, Basil";
    }
    public String getPizzaItems(){
        return "bread, pizza sauce, cheese";
    }
}
