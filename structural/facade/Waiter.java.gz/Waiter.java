package structural.facade;

public class Waiter {
  public static String deliverFood(FoodType foodtype){
    Ingredient ingredient = new Ingredient();
    switch(foodtype)
    {
        case Pasta:
            Pasta pasta = new Pasta();
            String pastaItems=ingredient.getPastaItems();
            pasta.prepareFood(pastaItems);
            return pasta.deliverFood();
        case Pizza:
            Pizza pizza = new Pizza();
            String pizzaItems=ingredient.getPizzaItems();
            pizza.prepareFood(pizzaItems);
            return pizza.deliverFood();
    }
    return null;
  }  


}

