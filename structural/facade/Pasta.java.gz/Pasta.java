package structural.facade;

public class Pasta {
    
    public String preparedItems;
    public void prepareFood(String itemsRequired){
        preparedItems = "Pasta with " + itemsRequired;

    }
    public String deliverFood(){
        return preparedItems;
    }
}
