public class Rectangle implements Shape {

    public void draw() {
        System.out.println("RECTANGLE is drawn");
    }
}