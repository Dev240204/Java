public class DecoratorPattern {
   public static void main(String[] args) {

      Shape circle = new Circle();

      Shape redCircle = new RedShapeDecorator(new Circle());

      Shape redRectangle = new RedShapeDecorator(new Rectangle());
      System.out.println("CIRCLE drawn with dotted border");
      circle.draw();

      System.out.println("\nCIRCLE drawn with blue border");
      redCircle.draw();

      System.out.println("\nRECTANGLE drawn with thin border");
      redRectangle.draw();
   }
}