public class Circle implements Shape {

    public void draw() {
        System.out.println("CIRCLE is drawn");
    }
}