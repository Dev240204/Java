import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CountryView extends JFrame {
    private JTextField nameField = new JTextField(10);
    private JLabel nameLabel = new JLabel("Name:");
    private JTextField populationField = new JTextField(10);
    private JLabel populationLabel = new JLabel("Population:");
    private JButton saveButton = new JButton("Save");

    public void addSaveListener(ActionListener listener) {
        saveButton.addActionListener(listener);
    }

    public CountryView() {
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(populationLabel);
        inputPanel.add(populationField);
        inputPanel.add(saveButton);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.CENTER);
        this.add(mainPanel);
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(250, 120);
        this.setVisible(true);
    }

    public String getName() {
        return nameField.getText();
    }

    public void setName(String name) {
        nameField.setText(name);
    }

    public int getPopulation() {
        return Integer.parseInt(populationField.getText());
    }

    public void setPopulation(int population) {
        populationField.setText(Integer.toString(population));
    }

    public void displayErrorMessage(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage);
    }
}
