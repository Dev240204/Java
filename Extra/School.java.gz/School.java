interface Pen {
    public void write(String str);
}
class PenAdapter implements Pen {
    PilotPen p = new PilotPen();
    public void write(String str){
        p.mark(str);
    }
}
class PilotPen {
    public void mark(String str){
        System.out.println(str);
    }
}
class AssignmentWork{
    private Pen p;
    public void setP(Pen p){
        this.p = p;
    }
    public void getP(){
        return p;
    }
    public void writeAssignment(String str){
        p.write(str);
    }
}
public class School {
    public static void main(String[] args) {
        Pen p = new PenAdapter();
        AssignmentWork aw = new AssignmentWork();
        aw.setP(p);
        aw.writeAssignment("Pen is being used to write the assignment");
    }
}
