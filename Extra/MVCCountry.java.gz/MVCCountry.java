public class MVCCountry {
    public static void main(String[] args) {
        CountryModel model = new CountryModel();
        CountryView view = new CountryView();
        CountryController controller = new CountryController(model, view);
        view.setVisible(true);
    }
}
