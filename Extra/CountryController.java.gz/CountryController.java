import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
public class CountryController {
    private CountryModel model;
    private CountryView view;
    
    public CountryController(CountryModel model, CountryView view) {
        this.model = model;
        this.view = view;
        
        view.addSaveListener(new SaveListener());
        view.setName(model.getName());
        view.setPopulation(model.getPopulation());
        view.addSaveListener(new CountryController.SaveListener());
        

    }
    
    class SaveListener implements ActionListener {
        private CountryModel model;
        private CountryView view;
    
        public SaveListener(CountryModel model, CountryView view) {
            this.model = model;
            this.view = view;
        }
    
        public void actionPerformed(ActionEvent e) {
            try {
                String name = view.getName();
                int population = view.getPopulation();
    
                // Update the model with the new data
                model.setName(name);
                model.setPopulation(population);
    
                // Display a success message
                JOptionPane.showMessageDialog(view, "Country data saved successfully!");
    
            } catch (NumberFormatException ex) {
                // Display an error message if the population is not a valid integer
                view.displayErrorMessage("Population must be a valid integer.");
            }
        }
    }
    
}
