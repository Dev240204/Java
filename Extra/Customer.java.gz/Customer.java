interface Food {
    public void prepareFood(String itemsRequired);
    public String deliverFood();
}
enum FoodType {
    PASTA,
    PIZZA
}
class Ingredient {
    public String getPizzaItems() {
        return "dough, pizza sause, Mozzarella Cheese";
    }
    public String getPastaItems() {
        return "flour, tomato paste, onion";
    }
}
class Pasta implements Food{
    public String preparedItem;
    @Override
    public void prepareFood(String itemsRequired) {
        // in the making
        preparedItem="Tomato pasta with ingredients - " + itemsRequired;
    }
    @Override
    public String deliverFood() {
        return preparedItem;
    }
}
class Pizza implements Food {
    public String preparedItem;
    @Override
    public void prepareFood(String itemsRequired) {
        // in the making
        preparedItem="Thin crust pizza with ingredients - " + itemsRequired;
    }
    @Override
    public String deliverFood() {
        return preparedItem;
    }
}

class Waiter {
    public static String deliverFood(FoodType foodType){
        Ingredient ingredient = new Ingredient();
        switch (foodType){
            case PIZZA:
                Food pizza= new Pizza() ;
                String pizzaItems = ingredient.getPizzaItems();
                pizza.prepareFood(pizzaItems);
                return pizza.deliverFood();
            case PASTA:
                Food pasta= new Pasta();
                String pastaItems = ingredient.getPastaItems();
                pasta.prepareFood(pastaItems);
                return pasta.deliverFood();
        }
        return null;
    }
}
public class Customer {
    public static void main(String[] args) {
        Ingredient ingredient = new Ingredient();
        Food pasta = new Pasta();
        String pastaItems = ingredient.getPastaItems();
        pasta.prepareFood(pastaItems);
        System.out.println(pasta.deliverFood());
        Food pizza= new Pizza() ;
        String pizzaItems = ingredient.getPizzaItems();
        pizza.prepareFood(pizzaItems);
        System.out.println(pizza.deliverFood());
        //Using Facade
        System.out.println("-------facade-------");
        System.out.println(Waiter.deliverFood(FoodType.PASTA));
        System.out.println(Waiter.deliverFood(FoodType.PIZZA)) ;
    }
}
