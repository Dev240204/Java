package Profile;

public class Main {
    public static void main(String[] args) {
        singleton s1 = singleton.getInstance();
        singleton s2 = singleton.getInstance();

        s1.setPlace("USA");
        s2.setPlace("Japan");

        System.out.println(s1.getPlace());

    }
}
