package Profile;

public class singleton {
    private static singleton soleInstance = new singleton();

    String place;
    private singleton()
    {
        System.out.println("Oh Nice to meet You!");
    }

    public  void setPlace(String Place)
    {
        this.place = Place;
    }

    public String getPlace()
    {
        return place;
    }

    public static singleton getInstance()
    {
        return soleInstance;
    }

}
