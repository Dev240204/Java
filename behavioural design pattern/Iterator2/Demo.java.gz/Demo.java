interface Iterator {
    public boolean hasNext();

    public Object next();
}

interface Container {
    public Iterator getIterator();
}

class MusicTrack implements Container {
    public String tracks[] = { "Track1", "Track2", "Track3", "Track4" };

    public Iterator getIterator() {
        return new MusicIterator();
    }

    private class MusicIterator implements Iterator {
        int index;

        public boolean hasNext() {
            if (index < tracks.length) {
                return true;
            }
            return false;
        }

        public Object next() {
            if (this.hasNext()) {
                return tracks[index++];
            }
            return null;
        }
    }
}

public class Demo {
    public static void main(String[] args) {
        MusicTrack mTrack = new MusicTrack();
        for (Iterator iter = mTrack.getIterator(); iter.hasNext();) {
            String name = (String) iter.next();
            System.out.println("Music : " + name);
        }
    }
}
