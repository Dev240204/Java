public class statedemo {
    public static void main(String[] args) {
            context c = new context();
            start s = new start();
            s.doAction(c);
            System.out.println(c.getState().toString());

            stop stopState = new stop();
            stopState.doAction(c);
      
            System.out.println(c.getState().toString());
}
}
