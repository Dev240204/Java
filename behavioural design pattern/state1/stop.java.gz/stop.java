public class stop implements state {
    public void doAction(context c) {
        System.out.println("Player is in stop state");
        c.setState(this);
    }

    public String toString() {
        return "Stop State";
    }
}
