public interface state {
    public void doAction(context c);
}
