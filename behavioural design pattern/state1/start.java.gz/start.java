public class start implements state {
    public void doAction(context c) {
        System.out.println("Player is in start state");
        c.setState(this);
    }

    public String toString() {
        return "Start State";
    }
}
    
