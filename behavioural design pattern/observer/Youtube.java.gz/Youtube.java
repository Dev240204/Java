import java.util.ArrayList;
import java.util.List;

interface Observer {
	void update();

	void subscribeChannel(Channel ch);
}

interface Subject {
	void subscribe(Subscriber sub);

	void unsubscribe(Observer sub);

	void notifySubscriber();

	void upload(String title);
}

class Subscriber implements Observer {
	private String name;
	private Channel channel = new Channel();

	public Subscriber(String name) {
		this.name = name;
	}

	public void update() {
		System.out.println("Hey " + name + "! Video uploaded on : " + channel.title);
	}

	public void subscribeChannel(Channel ch) {
		channel = ch;
	}
}

class Channel implements Subject {
	private List<Subscriber> subs = new ArrayList<Subscriber>();
	public String title;

	public void subscribe(Subscriber sub) {
		subs.add(sub);
	}

	public void unsubscribe(Observer sub) {
		subs.remove(sub);
	}

	public void notifySubscriber() {
		for (Observer sub : subs) {
			sub.update();
		}
	}

	public void upload(String title) {
		this.title = title;
		notifySubscriber();
	}
}

public class Youtube {
	public static void main(String args[]) {
		Channel Design = new Channel();
		Subscriber s1 = new Subscriber("Ram");
		Subscriber s2 = new Subscriber("Hari");
		Subscriber s3 = new Subscriber("Sonam");
		Subscriber s4 = new Subscriber("Kiran");
		Subscriber s5 = new Subscriber("Ali");
		Design.subscribe(s1);
		Design.subscribe(s2);
		Design.subscribe(s3);
		Design.subscribe(s4);
		Design.subscribe(s5);
		s1.subscribeChannel(Design);
		s2.subscribeChannel(Design);
		s3.subscribeChannel(Design);
		s4.subscribeChannel(Design);
		s5.subscribeChannel(Design);
		Design.upload("Observer Design Pattern");
		Design.unsubscribe(s3);
		s1.subscribeChannel(Design);
		s2.subscribeChannel(Design);
		s4.subscribeChannel(Design);
		s5.subscribeChannel(Design);
		Design.upload("DBMS");
	}
}
