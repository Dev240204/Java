public class mobile {
    public static void main(String[] args) {
        mobilecontext c = new mobilecontext();
        c.alert();
        c.setstate(new silent());
        c.alert();
        c.setstate(new ringing());
        c.alert();
    }
}
