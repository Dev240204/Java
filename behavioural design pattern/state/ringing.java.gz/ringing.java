public class ringing implements mobilealert {
    @Override
    public void alert() {
        System.out.println("Ringing");
    }
}

