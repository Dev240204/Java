public class silent implements mobilealert {
    public void alert() {
        System.out.println("silent");
    }
}
