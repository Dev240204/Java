public class mobilecontext {
    private mobilealert currentstate;
    public mobilecontext() {
        currentstate = new ringing();
    }
    public void setstate(mobilealert state) {
        currentstate = state;
    }
    public void alert() {
        currentstate.alert();
    }
}
