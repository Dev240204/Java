public interface mobilealert {
    public void alert();
}
