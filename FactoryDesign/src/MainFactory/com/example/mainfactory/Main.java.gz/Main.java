package MainFactory.com.example.mainfactory;
import com.example.phonefactory.*;

public class Main {
    public static void main(String[] args) {
        OperatingFactory OF = new OperatingFactory();
        OS a= OF.getInstance("Other");
        a.spec();

    }
}
