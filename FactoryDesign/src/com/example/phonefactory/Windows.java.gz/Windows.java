package com.example.phonefactory;

public class Windows implements OS{
    public void spec()
    {
        System.out.println("I am not that bad as well");
    }
}
