package com.example.phonefactory;

public class IOS implements OS {

    @Override
    public void spec() {
        System.out.println("I am even better");
    }
}
