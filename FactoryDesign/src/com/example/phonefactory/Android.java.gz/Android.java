package com.example.phonefactory;

public class Android implements OS {
    public void spec()
    {
        System.out.println("Best in the world");
    }
}
