package com.example.phonefactory;

public interface OS {
    public  void spec();
}
