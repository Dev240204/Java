package com.example.phonefactory;

public class OperatingFactory {
    public OS getInstance(String str)
    {
        if(str.equals("Closed"))
            return new IOS();
        else if (str.equals("Open"))
            return new Android();
        else
            return new Windows();

    }
}
