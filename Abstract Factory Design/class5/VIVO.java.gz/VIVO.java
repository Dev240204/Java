package class5;

public class VIVO extends Device{
    private String RAM;
    private String Processor;

    public VIVO(String RAM, String processor) {
        this.RAM = RAM;
        this.Processor = processor;
    }

    @Override
    public String getDetails() {
        return "VIVO config is RAM size: "+this.RAM+" and Processor type: "+this.Processor;
    }

    @Override
    public String toString() {
        return "VIVO{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                '}';
    }
}
