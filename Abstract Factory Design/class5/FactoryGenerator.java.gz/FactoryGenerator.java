package class5;

public abstract class FactoryGenerator {
    public static AbstractDeviceFactory getFactory(FactoryType Ftype){
        switch (Ftype)
        {
            case MOBILEFACTORY: return new MobileFactory();
            case LAPTOPFACTORY: return new LaptopFactory();
        }
        return null;
    }
}