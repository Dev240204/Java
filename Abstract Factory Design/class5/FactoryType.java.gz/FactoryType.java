package class5;

public enum FactoryType {
    LAPTOPFACTORY,
    MOBILEFACTORY
}
