package class5;

public class LaptopFactory extends AbstractDeviceFactory{
    @Override
    Device getGadget(DeviceType deviceType) {
        switch (deviceType)
        {
            case HP:return new HP("8GB","Intel","NVIDIA");
            case DELL:return new DELL("4GB","AMD","RADEON");
            case MICROSOFT:return new MICROSOFT("12GB","AMD","NVIDIA");
            case LENEVO:return new LENEVO("8GB","Intel","NVIDIA");
        }
        return null;
    }
}
