package class5;

public class MobileFactory extends AbstractDeviceFactory{
    @Override
    Device getGadget(DeviceType deviceType) {
        switch (deviceType)
        {
            case APPLE: return new APPLE("8GB","A13 BIONIC");
            case ONEPLUS: return new ONEPLUS("12GB", "801 SNAPDRAGON");
            case NOKIA: return new NOKIA("4GB","710 SNAPDRAGON");
            case OPPO:return new OPPO("8GB","460 SNAPDRAGON");
            case VIVO:return new VIVO("4GB","662 SNAPDRAGON");
        }
        return null;
    }
}
