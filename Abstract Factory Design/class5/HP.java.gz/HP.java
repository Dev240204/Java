package class5;

public class HP extends Device{
    private String RAM;
    private String Processor;
    private String GPU;

    public HP(String RAM, String processor, String GPU) {
        this.RAM = RAM;
        this.Processor = processor;
        this.GPU = GPU;
    }

    @Override
    public String getDetails() {
        return "HP config is RAM size: "+this.RAM+" and Processor type: "+this.Processor+" and GPU type: "+this.GPU;
    }

    @Override
    public String toString() {
        return "HP{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                ", GPU='" + GPU + '\'' +
                '}';
    }
}
