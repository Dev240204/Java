package class5;

public enum DeviceType {
    DELL,
    HP,
    LENEVO,
    MICROSOFT,
    APPLE,
    ONEPLUS,
    NOKIA,
    OPPO,
    VIVO
}
