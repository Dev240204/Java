package class5;

public class LENEVO extends Device{
    private String RAM;
    private String Processor;
    private String GPU;

    public LENEVO(String RAM, String processor, String GPU) {
        this.RAM = RAM;
        this.Processor = processor;
        this.GPU = GPU;
    }

    @Override
    public String getDetails() {
        return "LENEVO config is RAM size: "+this.RAM+" and Processor type: "+this.Processor+" and GPU type: "+this.GPU;
    }

    @Override
    public String toString() {
        return "LENEVO{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                ", GPU='" + GPU + '\'' +
                '}';
    }
}
