package class5;

public class APPLE extends Device{
    private String RAM;
    private String Processor;

    public APPLE(String RAM, String processor) {
        this.RAM = RAM;
        this.Processor = processor;
    }

    @Override
    public String getDetails() {
        return "APPLE config is RAM size: "+this.RAM+" and Processor type: "+this.Processor;
    }

    @Override
    public String toString() {
        return "APPLE{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                '}';
    }
}
