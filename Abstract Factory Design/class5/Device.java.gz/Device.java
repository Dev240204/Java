package class5;

public abstract class Device {
    public abstract String getDetails();
}
