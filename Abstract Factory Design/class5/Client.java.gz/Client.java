package class5;

import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        Device dell = FactoryGenerator.getFactory(FactoryType.LAPTOPFACTORY).getGadget(DeviceType.DELL);
        Device hp = FactoryGenerator.getFactory(FactoryType.LAPTOPFACTORY).getGadget(DeviceType.HP);
        Device microsoft = FactoryGenerator.getFactory(FactoryType.LAPTOPFACTORY).getGadget(DeviceType.MICROSOFT);
        Device lenevo = FactoryGenerator.getFactory(FactoryType.LAPTOPFACTORY).getGadget(DeviceType.LENEVO);

        Device apple = FactoryGenerator.getFactory(FactoryType.MOBILEFACTORY).getGadget(DeviceType.APPLE);
        Device oneplus = FactoryGenerator.getFactory(FactoryType.MOBILEFACTORY).getGadget(DeviceType.ONEPLUS);
        Device nokia = FactoryGenerator.getFactory(FactoryType.MOBILEFACTORY).getGadget(DeviceType.NOKIA);
        Device vivo = FactoryGenerator.getFactory(FactoryType.MOBILEFACTORY).getGadget(DeviceType.VIVO);
        Device oppo = FactoryGenerator.getFactory(FactoryType.MOBILEFACTORY).getGadget(DeviceType.OPPO);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Laptop and Mobile Specifications Interface : ");
        System.out.println("ENTER 0 to go for Laptop Specifications:\n" +
                "ENTER 1 to go for Mobile Specifications:\n");
        int user_input_1 = scanner.nextInt();
        switch (user_input_1) {
            case 0: {
                System.out.println("Welcome to Laptop Specification interface : ");
                System.out.println("for DELL Press 0:\n" +
                        "for HP Press 1:\n" +
                        "for MICROSOFT Press 2:\n" +
                        "for LENEVO Press 3:\n");
                int user_input_2 = scanner.nextInt();
                switch (user_input_2) {
                    case 0:
                        System.out.println(dell.getDetails());
                        break;
                    case 1:
                        System.out.println(hp.getDetails());
                        break;
                    case 2:
                        System.out.println(microsoft.getDetails());
                        break;
                    case 3:
                        System.out.println(lenevo.getDetails());
                        break;
                    default:
                        System.out.println("Enter a valid number !");
                        break;
                }
                break;
            }
            case 1: {
                System.out.println("Welcome to Mobile Specification interface : ");
                System.out.println("for APPLE Press 0 :\n" +
                        "for ONEPLUS Press 1:\n" +
                        "for NOKIA Press 2:\n" +
                        "for OPPO Press 3:\n" +
                        "for VIVO Press 4:\n");
                int user_input_3 = scanner.nextInt();
                switch (user_input_3) {
                    case 0:
                        System.out.println(apple.getDetails());
                        break;
                    case 1:
                        System.out.println(oneplus.getDetails());
                        break;
                    case 2:
                        System.out.println(nokia.getDetails());
                        break;
                    case 3:
                        System.out.println(oppo.getDetails());
                        break;
                    case 4:
                        System.out.println(vivo.getDetails());
                    default:
                        System.out.println("Enter a valid number !");
                        break;
                }
                break;
            }
            default: {
                System.out.println(" Please Enter a valid Input!");
                break;
            }
        }
    }
}
