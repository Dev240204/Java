package class5;

public class NOKIA extends Device{
    private String RAM;
    private String Processor;

    public NOKIA(String RAM, String processor) {
        this.RAM = RAM;
        this.Processor = processor;
    }

    @Override
    public String getDetails() {
        return "Nokia config is RAM size: "+this.RAM+" and Processor type: "+this.Processor;
    }

    @Override
    public String toString() {
        return "NOKIA{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                '}';
    }
}
