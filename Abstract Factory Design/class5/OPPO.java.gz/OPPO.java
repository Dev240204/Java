package class5;

public class OPPO extends Device{
    private String RAM;
    private String Processor;

    public OPPO(String RAM, String processor) {
        this.RAM = RAM;
        this.Processor = processor;
    }

    @Override
    public String getDetails() {
        return "OPPO config is RAM size: "+this.RAM+" and Processor type: "+this.Processor;
    }

    @Override
    public String toString() {
        return "OPPO{" +
                "RAM='" + RAM + '\'' +
                ", Processor='" + Processor + '\'' +
                '}';
    }
}
