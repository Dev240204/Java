package Animal;

public class Tiger implements Animal{


    public Tiger()
    {
        System.out.println("Tiger is created!");
    }
    @Override
    public Animal makeCopy() {

        System.out.println("Tiger is being  cloned...");
        Tiger tigerObject = null;

        try{
            tigerObject = (Tiger) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        return tigerObject;
    }

    public String toString()
    {
        return "I am a Tiger";
    }
}
