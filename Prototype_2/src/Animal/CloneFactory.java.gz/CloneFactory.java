package Animal;

public class CloneFactory {

    public Animal getClone(Animal sample)
    {
        return sample.makeCopy();
    }
}
