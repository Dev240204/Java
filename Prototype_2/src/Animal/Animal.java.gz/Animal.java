package Animal;

public interface Animal extends Cloneable{
    public Animal makeCopy();

}
