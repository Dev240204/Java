package Animal;

public class Main {
    public static void main(String[] args) {

        CloneFactory fact = new CloneFactory();
        Tiger animal1 = new Tiger();

        Tiger cloneAnimal1 = (Tiger) fact.getClone(animal1);

        System.out.println(animal1);
        System.out.println(cloneAnimal1);

        System.out.println("Original Hashcode: " + System.identityHashCode(animal1));
        System.out.println("Clone Hashcode: " + System.identityHashCode(cloneAnimal1));
    }
}
