package Prototype;

public class blueColor extends Color {

    void addColor()
    {
        System.out.println("Blue Color is Added");
    }
}
