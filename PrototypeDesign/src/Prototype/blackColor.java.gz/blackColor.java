package Prototype;

public class blackColor extends Color{

    void addColor()
    {
        System.out.println("Black Color is Added");
    }
}
