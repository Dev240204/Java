package Prototype;

public class Main {
    public static void main(String[] args) {

        ColorStore colS = new ColorStore();

        colS.getColor("blue").addColor();
        colS.getColor("black").addColor();
        colS.getColor("blue").addColor();
    }
}
