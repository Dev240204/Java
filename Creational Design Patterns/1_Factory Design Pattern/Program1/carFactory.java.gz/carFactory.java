interface car{
    void run();
    void topSpeed();
}

class rollsRoyce implements car{
    public void run(){
        System.out.println("Rolls Royce - the best car is running...");
    }
    public void topSpeed(){
        System.out.println("The Top Speed: 200kmph\n");
    }
}

class bmw implements car{
    public void run(){
        System.out.println("BMW, can't be compared with anyone, is running...");
    }
    public void topSpeed(){
        System.out.println("The Top Speed: 240kmph\n");
    }
}

class mercedes implements car{
    public void run(){
        System.out.println("Mercedes, the top class car is running...");
    }
    public void topSpeed(){
        System.out.println("The Top Speed: 280kmph\n");
    }
}

class  mclerenP1 implements car{
    public void run(){
        System.out.println("Mcleren P1 car is running...");
    }
    public void topSpeed(){
        System.out.println("The Top Speed: 400kmph\n");
    }
}

class CarConstructor{

    car construct(String carModel){
        if(carModel.equalsIgnoreCase("Rolls Royce")){
            return new rollsRoyce();
        }
        else if(carModel.equalsIgnoreCase("BMW")){
            return new bmw();
        }
        else if(carModel.equalsIgnoreCase("Mercedes")){
            return new mercedes();
        }
        else if(carModel.equalsIgnoreCase("Mcleren P1")){
            return new mclerenP1();
        }
        else{
            return null;
        }
    }
}

class carFactory{
    public static void main(String args[]){

        CarConstructor F1 = new CarConstructor();
        car c1 = F1.construct("mercedes");
        c1.run();
        c1.topSpeed();

        car c2 = F1.construct("mcleren p1");
        c2.run();
        c2.topSpeed();

        car c3 = F1.construct("bmw");
        c3.run();
        c3.topSpeed();
        
    }
}
