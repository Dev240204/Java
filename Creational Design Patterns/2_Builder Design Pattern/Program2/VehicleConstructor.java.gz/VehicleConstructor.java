class vehicle{
    String vehicleType;
    String brandName;
    int seatsAvailable;
    String engineType;
    String fuelType;

    vehicle(String vehicleType, String brandName, int seatsAvailable, String engineType, String fuelType){
        super();
        this.vehicleType = vehicleType;
        this.brandName = brandName;
        this.seatsAvailable = seatsAvailable;
        this.engineType = engineType;
        this.fuelType = fuelType;
    }

    public String toString(){
        return "Vehicle : \n  Vehicle Type = " + vehicleType + "\n  Brand Name = " + brandName + "  \n  Seats Available = " + seatsAvailable + "  \n  Engine Type = " + engineType + " \n  Fuel Type = " + fuelType;
    }
}

class vechicleBuilder{
    String vehicleType;
    String brandName;
    int seatsAvailable;
    String engineType;
    String fuelType;

    vechicleBuilder setvehicleType(String vehicleType){
        this.vehicleType = vehicleType;
        return this;
    }

    vechicleBuilder setbrandName(String brandName){
        this.brandName = brandName;
        return this;
    }

    vechicleBuilder setseatsAvailable(int seatsAvailable){
        this.seatsAvailable = seatsAvailable;
        return this;
    }

    vechicleBuilder setengineType(String engineType){
        this.engineType = engineType;
        return this;
    }

    vechicleBuilder setfuelType(String fuelType){
        this.fuelType =fuelType;
        return this;
    }

    vehicle getVehicle(){
        return new vehicle(vehicleType, brandName, seatsAvailable, engineType, fuelType);
    }

}

public class VehicleConstructor {
    public static void main(String args[]){

        vehicle v1 = new vehicle("Car", "Hyundai", 5, "V8 Engine", "Diesel");
        System.out.println(v1);
        System.out.println("\n");
        vehicle v2 = new vehicle("Bike", "Hero Honda", 2, "V4", "Petrol");
        System.out.println(v2);
    }
}
