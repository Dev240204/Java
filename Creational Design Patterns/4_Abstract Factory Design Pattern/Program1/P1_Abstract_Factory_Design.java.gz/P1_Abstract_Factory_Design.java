
interface Car{
    void carRuns();
}

class sportsCar implements Car{
    @Override
    public void carRuns() {
        System.out.println(" >> Sports-Car Created.");
        System.out.println("Sports-Car is Running...");
    }
}
class superCars implements Car{
    @Override
    public void carRuns() {
        System.out.println(" >> Super-Car Created.");
        System.out.println("Super-Car is Running...");
    }
}
class economicCars implements Car{
    @Override
    public void carRuns() {
        System.out.println(" >> Economic-Car Created.");
        System.out.println("Economic-Car is Running...");
    }
}

// ************************************************************************************************

interface Bike{
    void bikeRuns();
}

class superBike implements Bike{
    @Override
    public void bikeRuns() {
        System.out.println(" >> Super-Bike Created.");
        System.out.println("Super-Bike is Running...");
    }
}
class sportsBike implements Bike{
    @Override
    public void bikeRuns() {
        System.out.println(" >> Sports-Bike Created.");
        System.out.println("Sports-Bike is Running...");
    }
}
class economicBike implements Bike{
    @Override
    public void bikeRuns() {
        System.out.println(" >> Economic-Bike Created.");
        System.out.println("Economic-Bike  is Running...");
    }
}

// ************************************************************************************************

abstract class AbstractFactory{
    abstract Car getCar(String car);
    abstract Bike getBike(String bike);
}

class CarCompany extends AbstractFactory{
    // getShape method returns object of input type shape
    @Override
    public Car getCar(String carType){
        if(carType == null){
            return null;
        }
        if (carType.equalsIgnoreCase("sportsCar")) {
            return new sportsCar();
        }
        if (carType.equalsIgnoreCase("superCars")) {
            return new superCars();
        }
        if (carType.equalsIgnoreCase("economicCars")) {
            return new economicCars();
        }
        
        return null;
    }
    
    @Override
    Bike getBike(String Bike){
        return null;
    }
}

class BikeCompany extends AbstractFactory{
    // getShape method returns object of input type shape
    @Override
    public Bike getBike(String carType){
        if(carType == null){
            return null;
        }
        if (carType.equalsIgnoreCase("sportsBike")) {
            return new sportsBike();
        }
        if (carType.equalsIgnoreCase("superBike")) {
            return new superBike();
        }
        if (carType.equalsIgnoreCase("economicBike")) {
            return new economicBike();
        }
        
        return null;
    }
    
    @Override
    Car getCar(String car){
        return null;
    }
}

// ************************************************************************************************

class FactoryProducer {
    public static AbstractFactory getFactory(String choice){ 
        if(choice.equalsIgnoreCase("Car")){
            return new CarCompany();
        }
        else if(choice.equalsIgnoreCase("Bike")){
            return new BikeCompany();
        }
        return null;
    } 
}

// ************************************************************************************************

class P1_Abstract_Factory_Design{
    public static void main(String args[]) {
        System.out.println("\n");
        
        // Getting Car Company
        AbstractFactory carCompany = FactoryProducer.getFactory("Car");
        Car c1 = carCompany.getCar("superCars");
        c1.carRuns();

        System.out.println("\n");
        
        // Getting Bike Company
        AbstractFactory bikeCompnay = FactoryProducer.getFactory("Bike");
        Bike b1 = bikeCompnay.getBike("EconomicBike");
        b1.bikeRuns();
        
        System.out.println("\n");
    }
}
