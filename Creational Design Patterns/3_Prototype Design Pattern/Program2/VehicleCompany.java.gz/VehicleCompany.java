import java.util.ArrayList;
import java.util.List;

class Vehicle {
    private int vehicleNo;
    private String vName;

    public int getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(int vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    @Override
    public String toString() {
        return "Vehicle [Vehicle Number = " + vehicleNo + ", Vehicle Name = " + vName + "]";
    }

}

class vehicleShowrooom {
    private String showroomName;
    List<Vehicle> Vehicles = new ArrayList<>();

    public String getshowroomName() {
        return showroomName;
    }

    public void setshowroomName(String showroomName) {
        this.showroomName = showroomName;
    }

    public List<Vehicle> getVehicles() {
        return Vehicles;
    }

    public void setVehicles(List<Vehicle> Vehicles) {
        this.Vehicles = Vehicles;
    }

    public void loadData() {
        for (int i = 1; i <= 10; i++) {
            Vehicle v = new Vehicle();
            v.setVehicleNo(i);
            v.setvName("Vehicle " + i);
            getVehicles().add(v);
        }
    }

    @Override
    public String toString() {
        return "Vehicle Showroom [Showroom Name = " + showroomName + ", Vehicles = " + Vehicles + "]";
    }
}

public class VehiceCompany {
    public static void main(String args[]) {

        vehicleShowrooom VS = new vehicleShowrooom(); // try to create object bs
        System.out.println(VS); // print will return null values
        VS.setshowroomName("Showroom-1");
        VS.loadData();
        System.out.println("\n");
        System.out.println(VS);

        vehicleShowrooom VS1 = new vehicleShowrooom();
        VS1.setshowroomName("Showroom-2");
        VS1.loadData();
        System.out.println("\n");
        System.out.println(VS1);

    }
}
