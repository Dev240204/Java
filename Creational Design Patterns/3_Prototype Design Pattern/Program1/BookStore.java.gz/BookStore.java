import java.util.ArrayList;
import java.util.List;

class Book {
    private int bookId;
    private String bname;

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    @Override
    public String toString() {
        return "Book [Book Id = " + bookId + ", Book Name = " + bname + "]";
    }

}

class BookShop {
    private String shopName;
    List<Book> books = new ArrayList<>();

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public void loadData() {
        for (int i = 1; i <= 10; i++) {
            Book b = new Book();
            b.setBookId(i);
            b.setBname("Books " + i);
            getBooks().add(b);
        }
    }

    @Override
    public String toString() {
        return "BookShop [Shop Name = " + shopName + ", Books = " + books + "]";
    }
}

public class BookStore {
    public static void main(String args[]) {

        BookShop bs = new BookShop(); // try to create object bs
        System.out.println(bs); // print will return null values
        bs.setShopName("Shop1");
        bs.loadData();
        System.out.println("\n");
        System.out.println(bs);

        BookShop bs1 = new BookShop();
        bs1.setShopName("Shop2");
        bs1.loadData();
        System.out.println("\n");
        System.out.println(bs1);

    }
}
